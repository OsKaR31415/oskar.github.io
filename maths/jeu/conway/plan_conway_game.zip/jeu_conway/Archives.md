- bibliothèque
- Un livre (type notebook)

# [[prendre le livre]]
