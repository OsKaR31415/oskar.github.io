- porte d'entrée
- fenêtre à gauche


# [[hall]]
