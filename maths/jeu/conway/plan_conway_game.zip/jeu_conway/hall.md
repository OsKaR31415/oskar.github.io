- à gauche: le bureau
- devant: les archives
- derrière: l'entrée (inutile et hors-champ)
- à droite : cuisine
écrire le nom des pièces sur les portes

# [[bureau]]
# Archives : fermé à clef
# [[Archives_fermées]]
# [[cuisine_ao]] : gardée par le chat