- plus de clef (ca ne change pas le dessin)
- l'ordi est toujours le même mais on sait maintenant s'en servir

# [[ordi_ao]]

retour
# [[hall_ao]]