- le livre est compréhensible seulemet avec le miroir
- il explique le doomsay et le jour sur l'ordi de Conway

boutton de retour :
# [[Archives_avec_livre_posé]]