
- Un livre (type notebook)
- titre : "notes"
- l'écriture est bizzare (inversée : mirroir)

boutton retour : pas un vrai retour mais une nouvelle image : le livre est posé

# [[Archives_avec_livre_posé]]