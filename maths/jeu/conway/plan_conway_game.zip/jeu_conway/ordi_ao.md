- l'ordi demande le jour :
```
27 janvier 2002
>
```

si on entre le bon jour, on peut déverouiller l'ordi

# [[ordi_ouvert_ao]]

