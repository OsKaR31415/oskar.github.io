- dessin du mirroir

On utilise le mirroir pour lire le livre
# [[lire le livre]]