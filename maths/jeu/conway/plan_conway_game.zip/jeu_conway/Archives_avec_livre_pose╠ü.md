- comme les archives **mais le livre est posé sur une table**
- on voit un mirroir qui était derrière le livre

# [[prendre le mirroir]]
# [[hall_ao]]
