- un chat garde la cuisine, et il semble agressif !
- il porte un appareil électronique (du siècle dernier)
- il pose une question :

```
Quel était le groupe préféré de Conway ?
>
```

Si la réponse est correcte : "monster" / "monstre"
# [[interieur_cuisine]]
ou bien retour :
# [[hall]]

